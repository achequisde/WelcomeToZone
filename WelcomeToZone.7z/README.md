# WelcomeToZone

A simple addon made for learning. Prints a message everytime you visit another zone.
